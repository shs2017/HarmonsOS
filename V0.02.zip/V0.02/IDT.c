#include <mylib.h>
#include <system.h>
#include <Hal.h>

extern void idt_flush(uint32);

idt_entry_t idt_entries[I86MAXINT];
idt_ptr_t   idt_ptr;


void init_hal() 
{
	init_idt();
}

void init_idt() 
{
    	idt_ptr.limit = sizeof(idt_entry_t) * I86MAXINT -1;
    	idt_ptr.base  = (uint32)&idt_entries;

    	memset ((void*)&idt_entries[0], 0, sizeof (idt_entry_t) * I86MAXINT-1);
	setgates(0 , (uint32)isr0 , 0x8, 0x8E);
	setgates(1 , (uint32)isr1 , 0x8, 0x8E);
	setgates(2 , (uint32)isr2 , 0x8, 0x8E);
	setgates(3 , (uint32)isr3 , 0x8, 0x8E);
	setgates(4 , (uint32)isr4 , 0x8, 0x8E);
	setgates(5 , (uint32)isr5 , 0x8, 0x8E);
	setgates(6 , (uint32)isr6 , 0x8, 0x8E);
	setgates(7 , (uint32)isr7 , 0x8, 0x8E);
	setgates(8 , (uint32)isr8 , 0x8, 0x8E);
	setgates(9 , (uint32)isr9 , 0x8, 0x8E);
	setgates(10, (uint32)isr10, 0x8, 0x8E);
	setgates(11, (uint32)isr11, 0x8, 0x8E);
	setgates(12, (uint32)isr12, 0x8, 0x8E);
	setgates(13, (uint32)isr13, 0x8, 0x8E);
	setgates(14, (uint32)isr14, 0x8, 0x8E);
	setgates(15, (uint32)isr15, 0x8, 0x8E);
	setgates(16, (uint32)isr16, 0x8, 0x8E);
	setgates(17, (uint32)isr17, 0x8, 0x8E);
	setgates(18, (uint32)isr18, 0x8, 0x8E);
	setgates(19, (uint32)isr19, 0x8, 0x8E);
	setgates(20, (uint32)isr20, 0x8, 0x8E);
	setgates(21, (uint32)isr21, 0x8, 0x8E);
	setgates(22, (uint32)isr22, 0x8, 0x8E);
	setgates(23, (uint32)isr23, 0x8, 0x8E);
	setgates(24, (uint32)isr24, 0x8, 0x8E);
	setgates(25, (uint32)isr25, 0x8, 0x8E);
	setgates(26, (uint32)isr26, 0x8, 0x8E);
	setgates(27, (uint32)isr27, 0x8, 0x8E);
	setgates(28, (uint32)isr28, 0x8, 0x8E);
	setgates(29, (uint32)isr29, 0x8, 0x8E);
	setgates(30, (uint32)isr30, 0x8, 0x8E);
	setgates(31, (uint32)isr31, 0x8, 0x8E);

	idt_flush((uint32)&idt_ptr);
}

void setgates(uint8 i, uint32 base, uint16 sel, uint8 flags)
{
	idt_entries[i].base_low		= base & 0xffff;
	idt_entries[i].base_high	= (base >> 16) & 0xffff;
	idt_entries[i].sel 		= sel;
	idt_entries[i].always_zero 	= 0;
	idt_entries[i].sel 		= flags; 
}

