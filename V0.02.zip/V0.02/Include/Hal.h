#ifndef  __IDT_H
#define  __IDT_H
#include "system.h"

#define I86MAXINT 256
struct Descriptor
{
	uint16 base_low; 
	uint16 sel;
	uint8  always_zero;
	uint8  flags;
	uint16 base_high;
} __attribute__((packed));
typedef struct Descriptor idt_entry_t;

struct IDT_ptr
{
	uint16 limit;
	uint32 base;
} __attribute__((packed));
typedef struct IDT_ptr idt_ptr_t; 

extern void init_hal();
extern void init_idt();
extern void setgates(uint8 i, uint32 base, uint16 sel, uint8 flags);
extern void InstallIDT();
//extern void init_hwd_irq();	


extern void isr0 ();
extern void isr1 ();
extern void isr2 ();
extern void isr3 ();
extern void isr4 ();
extern void isr5 ();
extern void isr6 ();
extern void isr7 ();
extern void isr8 ();
extern void isr9 ();
extern void isr10();
extern void isr11();
extern void isr12();
extern void isr13();
extern void isr14();
extern void isr15();
extern void isr16();
extern void isr17();
extern void isr18();
extern void isr19();
extern void isr20();
extern void isr21();
extern void isr22();
extern void isr23();
extern void isr24();
extern void isr25();
extern void isr26();
extern void isr27();
extern void isr28();
extern void isr29();
extern void isr30();
extern void isr31();

#endif 
