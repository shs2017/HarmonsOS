#ifndef __MYLIB_H
#define __MYLIB_H
#include "system.h"
#define NULL (void*) 0

extern void print_c(unsigned char msg);
extern void printf(char* str);
extern void ClearScreen();
extern void outb(unsigned short port, unsigned char value);
extern unsigned char inb(unsigned short port);
extern unsigned short inw(unsigned short port);
extern void CursorStart();
extern void MovCur();
extern void memset(uint8 *dest, uint8 val, uint32 len);

#endif
