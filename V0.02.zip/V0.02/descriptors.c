#include <HAL.h>
#include <system.h>
#include <mylib.h>

gdt_t GDT[5];					//five gdt tables because there are 5 descriptors(they are in the comments of the InstallGDT function)
gdt_ptr_t gdt_ptr;				//the struct we use

//Setup the 5 descriptors
void SetupGDT() {
	gdt_ptr.limit = (sizeof(gdt_ptr_t) * 5) - 1;
	gdt_ptr.base = (unsigned int)&GDT;
	WriteGate(0, 0, 0, 0, 0);			//NULL
	WriteGate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);	//Kernel Code(9A = 10011010) CF = 11001111
	WriteGate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);	//Kernel Data(92 = 10010010)
	WriteGate(3, 0, 0xFFFFFFFF, 0xFA, 0xCF);	//User Code(FA = 11111010)
	WriteGate(4, 0, 0xFFFFFFFF, 0xF2, 0xCF);	//User Data(F2 = 11111010)
	Asm_GDT((unsigned int)&gdt_ptr); //the address of it
}

//Write to the gates
void WriteGate(int num, unsigned int base, unsigned int limit, unsigned char attrib, unsigned char granularity) { 
	GDT[num].base_low = (base & 0xFFFF);
	GDT[num].base_middle = (base >> 16) & 0xFF;
	GDT[num].base_high = (base >> 24) & 0xFF;

	GDT[num].limit_low = (limit & 0xFFFF);

	GDT[num].granularity = (limit >> 16) & 0x0F;	//Remember we are only moving the low 8 bit of the limit
	GDT[num].granularity |= granularity & 0xF0;	//We assign granularity the bit-wise or of granularity because remember we masked the upper bits of th granularity
	GDT[num].attrib = attrib;			//Just set it
}

void InstallGDT() {
	SetupGDT();
	printf("GDT installed");
}
