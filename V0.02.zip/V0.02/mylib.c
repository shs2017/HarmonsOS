#include <mylib.h>
#include <system.h>

int x = 0;
int y = 0;
unsigned char curX=1;
unsigned char curY=1;

typedef unsigned size_t;

size_t strlen(const char *str);

void print_c(unsigned char msg) {
	if(msg == '\n') {
		y+=2;
		x=0;
		curY = y * 80;
		MovCur();
	}
	else {
		char* Cur_Pos = (char*) 0xb8000 + x * 2 + y * 80;	
		*Cur_Pos++ = msg;		
		*Cur_Pos = 0x4E;
		x++;
		Cur_Pos = (char*) 0xb8000 + x * 2 + y * 80;
		curX++;
		MovCur();
	}
}


//print a string
void printf(string str) {
	int i = 0;
	
	while(str[i]) {	
		print_c(str[i]);
		i++;
	}
	return;
}

//clear the screen
void ClearScreen() {
	char *clear_vidmem = (char*) 0xb8000;
	int i;	
	curX=0;
	curY=0;
	MovCur();
	for(i=0; i<=(80*25); i++) {
		clear_vidmem[i] = ' ';
		clear_vidmem++;
		clear_vidmem[i] = 0x4E;	
	}
}

//write byte
void outb(unsigned short port, unsigned char value) {
    asm volatile ("outb %1, %0" : : "dN" (port), "a" (value));
}

//read byte
unsigned char inb(unsigned short port) {
   unsigned char ret;
   asm volatile("inb %1, %0" : "=a" (ret) : "dN" (port));
   return ret;
}

//read word
unsigned short inw(unsigned short port) {
   unsigned short ret;
   asm volatile ("inw %1, %0" : "=a" (ret) : "dN" (port));
   return ret;
} 

void CursorStart() {
	curX=0;
	curY=0;
	MovCur();
}

void MovCur() {
	unsigned short CursorPosition = curX + curY * 80;
	CursorPosition = curX + curY * 80;
	outb(0x3D4, 14);	//We are setting the high bit
	outb(0x3D4, CursorPosition >> 8);
	outb(0x3D4, 15);	//We are setting the low bit
	outb(0x3D5, CursorPosition);
}

void memset(uint8 *dest, uint8 val, uint32 len)
{
    	uint8 *temp = (uint8 *)dest;
	for ( ; len != 0; len--) *temp++ = val;
}
