#include "mylib.h"
#include "system.h"
#include "Hal.h"

void kmain() {
	string Welcome = "Operating System is starting...\nWelcome to my Operating System\n";
	CursorStart();
	ClearScreen(); 
	printf(Welcome);	
//	init_hal();	
	
	for (;;) {
		;
	}
}
