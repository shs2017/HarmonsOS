opt="-Wall -O -fstrength-reduce -fomit-frame-pointer -finline-functions -nostdinc -fno-builtin -I./Include"
opt2="-ffreestanding -std=c99 -Wall -O -fstrength-reduce -fomit-frame-pointer -nostdinc -fno-builtin -c -fno-strict-aliasing -fno-common -fno-stack-protector"


cd
cd Desktop/V0.02

if test "`whoami`" != "root" ; then
	echo "You must be logged in as root to build(for loopback mounting)"
	echo "Enter 'su' or 'sudo bash' to switch to root"
	exit
fi


if [ ! -e MyOS.flp ]
then
	echo ">>> Creating new floppy image..."
	mkdosfs -C MyOS.flp 1440 || exit
fi


echo ">>> Assembling bootloader..."

nasm Stage1.asm -o Stage1.bin || exit
 

echo ">>> Assembling kernel loader..."

nasm Stage2.asm -o KRNLDR.SYS || exit

echo ">>> Assembling kernel..."	

gcc $opt -c main.c -o main.o

gcc $opt -c mylib.c -o mylib.o

gcc $opt -c IDT.c -o IDT.o

nasm -f aout interrupts.asm -o interrupts.o

ld -T link.ld -o KERNEL.BIN main.o mylib.o IDT.o interrupts.o

echo ">>> Adding bootloader to floppy image..."


dd status=noxfer conv=notrunc if=Stage1.bin of=MyOS.flp || exit


echo ">>> Copying kernel..."

rm -rf tmp-loop

mkdir tmp-loop && mount -o loop -t vfat MyOS.flp tmp-loop && cp KRNLDR.SYS tmp-loop/ && cp KERNEL.BIN tmp-loop/ && cp GDT.inc tmp-loop/ && cp A20.inc tmp-loop/ && cp common.inc tmp-loop/ && cp Fat12.inc tmp-loop/ && cp Floppy16.inc tmp-loop/ && cp stdio.inc tmp-loop/ && cp ./Include/mylib.h tmp-loop/ && cp ./Include/system.h tmp-loop / && cp Hal.h tmp-loop/

umount tmp-loop || exit

rm -rf tmp-loop || exit

rm -rf tmp-loop

echo "Coping floppy to build folder..."
cp MyOS.flp build/

echo "Removing first copy of floppy..."
rm MyOS.flp

echo "Building ISO image..."

mkisofs -quiet -V 'MYOS  ' -input-charset iso8859-1 -o build/MyOS.iso -b MyOS.flp build/

echo '>>> Done!'


