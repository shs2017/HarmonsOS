./Destroy.sh
./Start.sh
./Destroy.sh
umount tmp-loop
rm -rf tmp-loop
cd
cd Desktop/V0.02/build
qemu -fda MyOS.flp
