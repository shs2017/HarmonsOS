cd
cd Desktop/V0.02

cp interrupts.o build/objects
cp KERNEL.BIN build/objects
cp KRNLDR.SYS build/objects
cp main.o build/objects
cp mylib.o build/objects
cp Stage1.bin build/objects
cp IDT.o build/objects
rm interrupts.o
rm KERNEL.BIN
rm KRNLDR.SYS
rm main.o
rm mylib.o 
rm Stage1.bin 
rm IDT.o 
